
class Enemy
{
public:
	Enemy() {};
	Enemy::~Enemy() = default;

private:

};