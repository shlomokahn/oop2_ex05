#include <SFML/System/Vector2.hpp>


const sf::Vector2f SIZE_CAR = { 120, 245 };
const int KMH = 10;