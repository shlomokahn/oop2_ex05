#include <iostream>
#include "Controller.h"
#include "SrartWindow.h"

int main() {
    StartWindow startWindow;
	if (!startWindow.run())
		return 0; 


    return 0;
} 